# AirBnB_clone_v2
<p align="center">
  <img src="https://github.com/bdbaraban/AirBnB_clone/blob/master/assets/hbnb_logo.png" alt="HolbertonBnB logo">
</p>

<h1 align="center">AirBnB</h1>
<p align="center">An AirBnB clone.</p>

---
## Description :alx:

ALXBnB is a complete web application, integrating database storage,
a back-end API, and front-end interfacing in a clone of AirBnB.

The project currently only implements the back-end console.

## Authors:
* Marcus Imagwe <[Marcus Imagwe](https://github.com/Dr-Marcus)>
* Dennis Odibbo<[Dennis Odibbo](https://github.com/Denatkins)>
